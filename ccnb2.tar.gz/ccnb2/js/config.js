// js/config.js
export const APP_ROOT = "/ccnb2";
export const API_BASE = "/ccnb2/proxy";

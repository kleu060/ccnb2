export function Home() {
    return `

    `;
}
import { mockData } from "../../../components/mockData.js";
import DataTable from "datatables.net-bs5";
import "datatables.net-bs5/css/dataTables.bootstrap5.css";
import { API_BASE } from '../../../config.js';
import { fetchAPI } from '../../../../js/api/fetch-api.js';


const columnsConfig = {
    dunning_group: [
        
        { title: "ID", data: "id" },
        { title: "Dunn Group Name", data: "dunn_group_name" },
        { title: "Priority", data: "priority" },
        { title: "Remark", data: "remark" },

    ],
    dunning_group_setup: [
        {
            title: "Action",
            data: "action",
            defaultContent: '<button class="btn btn-primary">Edit</button>'
        },
        { title: "ID", data: "id" },
        { title: "Dunn Group Name", data: "dunn_group_name" },
        { title: "Priority", data: "priority" },
        { title: "Remark", data: "remark" },
    ],

    campaign_list: [
        { title: "Campaign ID", data: "id" },
        { title: "Campaign Name", data: "campaign_name" },
        { title: "Dunning Group Name", data: "dunning_group_name" },
        { title: "Validity", data: "validity" },
        { title: "Call Group", data: "callgroup" },
        { title: "Create Date", data: "create_date" },

    ],
    campaign_list_setup: [
        {
            title: "Action",
            data: "action",
            defaultContent: '<button class="btn btn-primary">Edit</button>'
        },
        { title: "Campaign ID", data: "id" },
        { title: "Campaign Name", data: "campaign_name" },
        { title: "Dunning Group Name", data: "dunning_group_name" },
        { title: "Overdue Days", data: "overdue_days" },
        { title: "Validity", data: "validity" },
        { title: "Status", data: "status" },
        { title: "Remark", data: "remark" },
    ],
    dunning_group_version: [
        { title: "ID", data: "id" },
        { title: "Dunning_group_name", data: "dunn_group_name" },
        { title: "Version", data: "version" },
        { title: "Status", data: "status" },
        { title: "Priority", data: "priority" },
        { title: "Criteria", data: "criteria" },
        { title: "Remark", data: "remark" },
    ],
    dunning_group_version_setup: [
        {
            title: "Action",
            data: "action",
            defaultContent: '<button class="btn btn-primary">Edit</button>'
        },
        { title: "ID", data: "id" },
        { title: "Dunning_group_name", data: "dunn_group_name" },
        { title: "Version", data: "version" },
        { title: "Status", data: "status" },
        { title: "Priority", data: "priority" },
        { title: "Criteria", data: "criteria" },
        { title: "Remark", data: "remark" },
    ],
    agent_management: [
        {
            title: "Action",
            data: "action",
            defaultContent: '<button class="btn btn-primary">Edit</button>'
        },
        {title: "User ID", data: "user_id"},
        {title: "Name", data: "user_name"},
        {title: "Full Name", data: "user_fullname"},
        {title: "Caller ID", data: "caller_id"},
        {title: "Caller Group", data: "callgroup_id"},
        {title: "Team ID", data: "team"},
        {title: "Status", data: "status"},
        // {title: "create_date", data: "create_date"},
    ]
    
};


// let table = null;
// let dunningGroupSetupTable = null;
export async function getDunningGroups() {
    // await new Promise(resolve => setTimeout(resolve, 200)); // simulate API
    // return mockData["dunning_group"] || [];

    const url = `${API_BASE}/dunningGroup.php?endpoint=list_dunning`;
    const responseJson = await fetchAPI(url);
    if ( responseJson.success == true ) {
        return JSON.parse(responseJson.response);
    }
    else {
        console.error("Failed to fetch Dunning Group data");
    }
}

async function getDunningVersion(dunningId) {
    const url = `${API_BASE}/dunningGroup.php?endpoint=list_dunning_version&dunning_id=${dunningId}`;
    const responseJson = await fetchAPI(url);
    if ( responseJson.success == true ) {
        return JSON.parse(responseJson.response);
    }
    else {
        console.error("Failed to fetch Dunning Group Version data");
    }
}

async function getDunningGroupsSetup() {
    await new Promise(resolve => setTimeout(resolve, 200)); // simulate API
    return mockData["dunning_group_setup"] || [];
}

const tableInstances = {
    read: null,
    setup: null,

};

export async function loadDunningGroupTable(isEdit = false) {

    let data = [];
    let columnConfg = "";
    let instanceKey  = "";
    let tableName = "";

    const type = "Dunning";
    const body = {type};
    const url = `${API_BASE}/getMapping.php`;
    const dunningConstantJson  = await fetchAPI(url, body);
    
    if ( isEdit ) {
        // const tmpData = await getDunningGroupsSetup();
        tableName = "dunning-group-setup-table";
        columnConfg = "dunning_group_setup";
        instanceKey  = "setup";
    }
    else {
        // const tmpData = await getDunningGroups();
        tableName = "dunning-group-table";
        columnConfg = "dunning_group";
        instanceKey  = "read";
    }
    // const dunningGroupStatus = dunningConstantJson.Campaign.Status;
    const tmpData = await getDunningGroups();
    for (const dg of tmpData) {
        if ( isEdit ) {
            let tmp = {   
                action: '<button class="btn btn-primary btn-edit-dunning-group" data-dunning-id="'+dg.id+'" data-dunning-name="'+dg.name+'" data-dunning-priority="'+dg.priority+'" data-dunning-remark="'+dg.remark+'">Edit</button> \
                        <button class="btn btn-primary btn-dunning-group-view-version" data-dunning-id='+ dg.id+' data-dunning-priority="'+dg.priority+'" data-dunning-group-name="'+dg.name+'">Version</button>',
                id: dg.id,
                dunn_group_name: dg.name,
                priority: dg.priority ?? "0",
                remark: dg.remark ?? "0",
                
            };
            data.push(tmp);
        }
        else {
            let tmp = {   
                
                id: dg.id,
                dunn_group_name: dg.name,
                priority: dg.priority ?? "0",
                remark: dg.remark ?? "0",
                
            };
            data.push(tmp);
        }

        // let versions = await getDunningVersion(dg.id);
        // if (Array.isArray(versions)) {
        //     versions.forEach(function(version) {
        //         const statusObj = Object.values(dunningGroupStatus).find(s => s.ID === Number(version.status));
        //         const statusDisplay = statusObj ? statusObj.DISPLAY : (version.status ?? "0");

        //         if ( isEdit ) {
        //             let tmp = {   
        //                 action: '<button class="btn btn-primary btn-edit-dunning-group">Edit</button> \
        //                             <button class="btn btn-primary btn-dunning-group-create-version" data-dunning-id='+ dg.id+' data-dunning-group-name="'+dg.name+'">Version</button>',
        //                 id: dg.id,
        //                 dunn_group_name: dg.name,
        //                 version: version.version ?? "1",
        //                 status: statusDisplay,
        //                 priority: dg.priority ?? "0",
        //                 criteria: '<button class="btn btn-primary show-criteria" data-dunning-group-id="'+ version.id +'">Show Criteria</button>',
        //                 create_date: version.create_date ?? "0000-00-00 00:00:00",
        //                 end_date: version.end_date ?? "0000-00-00 00:00:00",
        //             };
        //             data.push(tmp);
        //         }
        //         else {
           
        //             console.log(version);
        //             let tmp = {
        //                     id: dg.id,
        //                     dunn_group_name: dg.name,
        //                     version: version.version ?? "1",
        //                     status: statusDisplay,
        //                     priority: dg.priority ?? "0",
        //                     criteria: '<button class="btn btn-primary show-criteria" data-dunning-group-id="'+ version.id +'">Show Criteria</button>',
        //                     create_date: version.create_date ?? "0000-00-00 00:00:00",
        //                     end_date: version.end_date ?? "0000-00-00 00:00:00",
        //                 };

        //                 console.log(tmp);
        //                 data.push(tmp);
                   
        //         }
        //     });
        // }

    }
    
    console.log(data);
    // Cleanly destroy an existing instance if it was already initialized
    if (tableInstances[instanceKey]) {
        tableInstances[instanceKey].destroy();
        tableInstances[instanceKey] = null;
        const tableBody = document.querySelector(`#${tableName} tbody`);
        if (tableBody) tableBody.innerHTML = "";
    }

    // Create new DataTable
    tableInstances[instanceKey] = new DataTable("#" + tableName, {
        data: data,
        columns: columnsConfig[columnConfg],
        searching: false,
        stateSave: true
    });
}



// export async function loadDunningGroupSetupTable() {

//     const data = await getDunningGroupsSetup();
//     if (dunningGroupSetupTable) {
//         dunningGroupSetupTable.destroy();
//         document.querySelector("#dunning-group-setup-table tbody").innerHTML = "";
//         // document.querySelector("#user-management-table-header").innerHTML = "";
//     }

//     // Create new DataTable
//     dunningGroupSetupTable = new DataTable("#dunning-group-setup-table", {
//         data: data,
//         columns: columnsConfig["dunning_group_setup"],
//         searching: false,
//     });
// }


async function getCampaignList () {
    // await new Promise(resolve => setTimeout(resolve, 200)); // simulate API
    // return mockData["campaigns"] || [];
    const url = `${API_BASE}/dunningGroup.php?endpoint=list_internal_campaign`;
    const responseJson = await fetchAPI(url);
    if ( responseJson.success == true ) {
        return JSON.parse(responseJson.response);
    }
    else {
        console.error("Failed to fetch campaign data");
    }
}

async function getCampaignListSetup () {
    await new Promise(resolve => setTimeout(resolve, 200)); // simulate API
    return mockData["campaigns_setup"] || [];
}


let versionTable = null;
export async function loadDunningVersionTable(dunningGroupId, dunningGroupPriority, dunningGroupName , isEdit) {
    let versions = await getDunningVersion(dunningGroupId);
    
    const type = "Dunning";
    const body = {type};
    const url = `${API_BASE}/getMapping.php`;
    const dunningConstantJson  = await fetchAPI(url, body);
    const dunningGroupStatus = dunningConstantJson.DunningVersion.Status;
    let data = [];

    if (Array.isArray(versions)) {
        versions.forEach(function(version) {
            const statusObj = Object.values(dunningGroupStatus).find(s => s.ID === Number(version.status));
            const statusDisplay = statusObj ? statusObj.DISPLAY : (version.status ?? "0");
        
            if ( isEdit ) {
                let tmp = {   
                    action: '<button class="btn btn-primary btn-edit-dunning-version"' +  
                                'data-version-id="'+version.id+'" ' + 
                                'data-dunning-id="'+ dunningGroupId+'" ' +
                                'data-dunning-group-name="'+dunningGroupName+'" ' + 
                                'data-dunning-group-priority="'+dunningGroupPriority+'" ' + 
                                'data-version-number="'+version.version+'" ' + 
                                'data-version-status="'+version.status+'" ' +
                                'data-version-remark="'+version.remark+'">Edit</button> \
                            <button class="btn btn-primary btn-dunning-group-create-version" data-dunning-group-name="'+dunningGroupName+'" data-dunning-id="'+ dunningGroupId+'" data-dunning-group-priority="'+dunningGroupPriority+'" data-version-id="'+version.id+'" data-dunning-group-priority="'+dunningGroupPriority+'">New</button> \
                        ',
                    id: version.id,
                    dunn_group_name: dunningGroupName,
                    version: version.version ?? "1",
                    status: statusDisplay,
                    priority: dunningGroupPriority,
                    criteria: '<button class="btn btn-primary show-criteria" ' +  
                                'data-version-id="'+version.id+'" '+
                                'data-dunning-group-name="'+dunningGroupName+'" '+
                                'data-dunning-group-status="'+statusDisplay+'" '+
                                
                                '>Show Criteria</button>',
                    remark: version.remark,
                    
                };
                data.push(tmp);
            }
            else {
        
                let tmp = {
                        id: dg.id,
                        dunn_group_name: dunningGroupName,
                        version: version.version ?? "1",
                        status: statusDisplay,
                        priority: dunningGroupPriority ?? "0",
                        criteria: '<button class="btn btn-primary show-criteria" data-dunning-group-id="0">Show Criteria</button>',
                        remark: version.remark,
                        
                    };
                    console.log(tmp);
                    data.push(tmp);
            }
        });
    }

    console.log("version data:" );
    console.log(data);

    if (versionTable) {
        versionTable.destroy();
        versionTable = null;
        const tableBody = document.querySelector(`#dunning-group-version-table tbody`);
        if (tableBody) tableBody.innerHTML = "";
    }

    // Create new DataTable
    versionTable = new DataTable("#dunning-group-version-table", {
        data: data,
        columns: columnsConfig["dunning_group_version_setup"],
        searching: false,
        stateSave: true
    });


}
let campaignTable = null;
let campaignSetupTable = null;
export async function loadCampaignListTable(isEdit) {

    let data = [];

    let tableName = "";
    let columnConfg = "";

    if ( isEdit ) {
        const tmpData = await getCampaignList();
        tableName = "campaign-list-setup-table";
        columnConfg = "campaign_list_setup";

        const type = "Dunning";
        const body = {type};
        const url = `${API_BASE}/getMapping.php`;
        const dunningJson  = await fetchAPI(url, body);
    
        const campaignType = dunningJson.Campaign.Type;
        const campaignStatus = dunningJson.Campaign.Status;

        for (const campaign of tmpData) {


            const statusObj = Object.values(campaignStatus).find(s => s.ID === Number(campaign.status));
            const statusDisplay = statusObj ? statusObj.DISPLAY : (campaign.type ?? "0");

            let tmp = {   
                action: '<button class="btn btn-primary btn-edit-campaign-setting" data-campaign-id="'+campaign.id+'">Edit</button>',
                id: campaign.id,
                campaign_name: campaign.campaign_name,
                overdue_days: campaign.overdue_days,
                dunning_group_name: campaign.dunning_group_name,
                validity: campaign.validity ?? "",
                status: statusDisplay ?? "",
                remark: campaign.remark ?? "",
                
            };
            data.push(tmp);
        }

        if (campaignTable) {
            campaignTable.destroy();
            document.querySelector("#" + tableName + " tbody").innerHTML = "";
            // document.querySelector("#user-management-table-header").innerHTML = "";
        }

        
        // Create new DataTable
        campaignTable = new DataTable("#" + tableName, {
            data: data,
            columns: columnsConfig[columnConfg],
            searching: false,
            stateSave: true
        });
    }
    else {

        tableName = "campaign-list-table";
        const tmpData = await getCampaignList();
        columnConfg = "campaign_list";

        const type = "Dunning";
        const body = {type};
        const url = `${API_BASE}/getMapping.php`;

        // const dunningJson  = await fetchAPI(url, body);
        // const campaignType = dunningJson.Campaign.Type;

        for (const campaign of tmpData) {
            // const typeObj = Object.values(campaignType).find(s => s.ID === Number(campaign.type));
            // const typeDisplay = typeObj ? typeObj.DISPLAY : (campaign.type ?? "0");

            let tmp = {   
                id: campaign.id,
                campaign_name: campaign.campaign_name,
                dunning_group_name: campaign.dunning_group_name,
                validity: campaign.validity ?? "",
                callgroup: campaign.callgroup ?? "",
                create_date: campaign.create_date ?? "2026-09-15",
                
            };
            data.push(tmp);
        }

        if (campaignSetupTable) {
            campaignSetupTable.destroy();
            document.querySelector("#" + tableName + " tbody").innerHTML = "";
            // document.querySelector("#user-management-table-header").innerHTML = "";
        }

        
        // Create new DataTable
        campaignSetupTable = new DataTable("#" + tableName, {
            data: data,
            columns: columnsConfig[columnConfg],
            searching: false,
            stateSave: true
        });
    }
    console.log("loadCampaignListTable");
    console.log(data);

    
    
}

export async function getUserForAgent() {
    const url = `${API_BASE}/dunningGroup.php?endpoint=list_user_for_agent`;
    const responseJson = await fetchAPI(url);
    if ( responseJson.success == true ) {
        return JSON.parse(responseJson.response);
    }
    else {
        console.error("Failed to fetch Dunning Group Version data");
    }
} 


async function getAgents () {

    const url = `${API_BASE}/dunningGroup.php?endpoint=list_agent`;
    const responseJson = await fetchAPI(url);
    if ( responseJson.success == true ) {
        return JSON.parse(responseJson.response);
    }
    else {
        console.error("Failed to fetch Dunning Group Version data");
    }
}


let agentManagementTable = null;
export async function loadAgentManagementTable() {
    const agents = await getAgents();
    const tableName = "agent-management-table";

    let data = [];
    agents.forEach(function(agent) {
        let tmp = {   
            action: '<button class="btn btn-primary btn-edit-agent"' + 
                    'data-agent-id="'+agent.id+'">Edit</button>',
            user_id: agent.user_id,
            user_name: agent.user_name,
            user_fullname: agent.user_fullname,
            caller_id: agent.caller_id,
            callgroup_id: agent.callgroup_id,
            team: agent.team,
            status: agent.status
        };
        data.push(tmp);
    });


    if (agentManagementTable) {
        agentManagementTable.destroy();
        document.querySelector("#" + tableName + " tbody").innerHTML = "";
        // document.querySelector("#user-management-table-header").innerHTML = "";
    }

    // Create new DataTable
    agentManagementTable = new DataTable("#" + tableName, {
        data: data,
        columns: columnsConfig["agent_management"],
        searching: false,
        stateSave: true
    });

}

export async function getCampaignData () {

}

// export async function loadCampaignListSetupTable() {
//     const data = await getCampaignListSetup();
//     if (campaignSetupTable) {
//         campaignSetupTable.destroy();
//         document.querySelector("#campaign-list-setup-table tbody").innerHTML = "";
//         // document.querySelector("#user-management-table-header").innerHTML = "";
//     }

//     // Create new DataTable
//     campaignSetupTable = new DataTable("#campaign-list-setup-table", {
//         data: data,
//         columns: columnsConfig["campaign_list_setup"],
//         searching: false,
//     });
// }

import { logEvent } from '../logEvent.js';
import { APP_ROOT, API_BASE } from '../config.js';


export async function fetchAPI(url, data = "", contentType = "") {

    logEvent('info', 'API Request - ' + url + " with body: " + JSON.stringify(data));

    let body = null;
    if (contentType == "file ") {
        body = data;
    }
    else {
        body = JSON.stringify(data);
    }
    const response= await fetch(url, {
        method: "POST",
        // headers: {
        //     "Content-Type": "application/json"
        // },
        body: body,
        credentials: "include"
    });

    const responseJson = await response.json();

    const responseData = responseJson?.response ? JSON.parse(responseJson.response) : null;
    let errorCode;
    if (responseData && responseData.error_code) {
        errorCode = responseData.error_code;
    }

    if (!responseJson.success && errorCode ==  2) {

        const response= await fetch(`${API_BASE}/index.php?endpoint=logout`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            credentials: "include"
        });
        
        document.getElementById("expire-container").style.display = "block";
        //access token expire;
        setTimeout(function(){
            document.getElementById("expire-container").style.display = "none";
            window.location.href="/ccnb2/login?msg=Access token expired";
        }, 1000);
    }

    logEvent('info', 'API response - ' + JSON.stringify(responseJson) );
    return responseJson;
}
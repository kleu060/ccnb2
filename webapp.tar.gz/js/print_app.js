import "datatables.net-bs5/css/dataTables.bootstrap5.css";
import '../scss/app.scss';

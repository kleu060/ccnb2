// js/config.js
export const API_BASE = "http://192.168.82.181/proxy";

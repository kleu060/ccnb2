<?php
    // Allow requests from your Vite dev server
    header("Access-Control-Allow-Origin: http://192.168.82.181:5173");
    header("Access-Control-Allow-Credentials: true");
    header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
    header("Access-Control-Allow-Headers: Content-Type, Authorization");
    // Preflight check
    if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
        http_response_code(200);
        exit;
    }

    define('API_URL', 'http://192.168.82.173/ccnb2');
